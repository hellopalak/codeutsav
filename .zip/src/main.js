import './style.css';
import 'highlight.js/styles/github-dark.css';
import { marked } from 'marked';
import hljs from 'highlight.js';
import { DEFAULT_USER, INITIAL_CONVERSATIONS } from './mock-data.js';
import { AIService } from './ai-service.js';

// Setup marked with highlight.js
marked.setOptions({
  highlight: function (code, lang) {
    if (lang && hljs.getLanguage(lang)) {
      return hljs.highlight(code, { language: lang }).value;
    }
    return hljs.highlightAuto(code).value;
  },
  breaks: true,
  gfm: true
});

// SVGs
const ICONS = {
  chatgpt: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M22.28 9.87c-.15-.99-.58-1.92-1.25-2.67-.67-.76-1.54-1.3-2.52-1.57-.42-1.42-1.29-2.65-2.47-3.48-1.18-.83-2.6-1.25-4.04-1.19-1.4.05-2.73.57-3.83 1.48-1.1.91-1.87 2.16-2.2 3.56-1.3.38-2.43 1.17-3.23 2.25-.8 1.08-1.2 2.4-1.13 3.74.07 1.34.62 2.61 1.56 3.59.94.99 2.19 1.62 3.54 1.8.42 1.42 1.29 2.65 2.47 3.48 1.18.83 2.6 1.25 4.04 1.19 1.4-.05 2.73-.57 3.83-1.48 1.1-.91 1.87-2.16 2.2-3.56 1.3-.38 2.43-1.17 3.23-2.25.8-1.08 1.2-2.4 1.13-3.74-.07-1.34-.62-2.61-1.56-3.59-.28-.29-.59-.55-.92-.78.05-.28.08-.57.08-.86z" fill="#ececec"/></svg>`,
  chevronDown: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>`,
  search: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,
  sidebarToggle: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg>`,
  newChat: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>`,
  library: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m16 6 4 14M12 6v14M8 8v12M4 4v16"></path></svg>`,
  projects: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>`,
  scheduled: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`,
  plugins: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v4m0 12v4M2 12h4m12 0h4"></path><circle cx="12" cy="12" r="4"></circle></svg>`,
  codex: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg>`,
  more: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg>`,
  store: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"></path><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"></path><path d="M2 7h20"></path></svg>`,
  share: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path><polyline points="16 6 12 2 8 6"></polyline><line x1="12" y1="2" x2="12" y2="15"></line></svg>`,
  plus: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>`,
  think: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6"></path><path d="M10 22h4"></path><path d="M12 2a7 7 0 0 0-7 7c0 2.5 1.5 4.5 3 6h8c1.5-1.5 3-3.5 3-6a7 7 0 0 0-7-7z"></path></svg>`,
  mic: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>`,
  voiceWave: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="9" x2="6" y2="15"></line><line x1="10" y1="5" x2="10" y2="19"></line><line x1="14" y1="8" x2="14" y2="16"></line><line x1="18" y1="11" x2="18" y2="13"></line></svg>`,
  arrowUp: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>`,
  copy: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`,
  thumbsUp: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>`,
  thumbsDown: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h3a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2h-3"></path></svg>`,
  retry: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>`,
  speaker: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg>`,
  trash: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`,
  edit: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>`,
  close: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`
};

class ChatGPTApp {
  constructor() {
    this.aiService = new AIService();
    this.conversations = this.loadConversations();
    this.activeConversationId = this.conversations[0]?.id || 'bloomberg-ps-updates';
    this.thinkMode = false;
    this.isRecording = false;
    this.isSpeaking = false;
    this.attachedFiles = [];
    this.sidebarCollapsed = false;
    this.currentGenerating = false;

    this.initSpeechRecognition();
    this.render();
  }

  loadConversations() {
    const saved = localStorage.getItem('chatgpt_clone_conversations');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_CONVERSATIONS;
      }
    }
    return INITIAL_CONVERSATIONS;
  }

  saveConversations() {
    localStorage.setItem('chatgpt_clone_conversations', JSON.stringify(this.conversations));
  }

  getActiveConversation() {
    return this.conversations.find(c => c.id === this.activeConversationId) || this.conversations[0];
  }

  initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';

      this.recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const textarea = document.getElementById('chat-input');
        if (textarea) {
          textarea.value = (textarea.value ? textarea.value + ' ' : '') + transcript;
          this.autoResizeTextarea(textarea);
          this.updateSendButtonState();
        }
        this.setRecording(false);
      };

      this.recognition.onerror = () => {
        this.setRecording(false);
        this.showToast('Microphone input error or permission denied.');
      };

      this.recognition.onend = () => {
        this.setRecording(false);
      };
    }
  }

  setRecording(recording) {
    this.isRecording = recording;
    const micBtn = document.getElementById('mic-btn');
    if (micBtn) {
      micBtn.classList.toggle('recording', recording);
    }
  }

  toggleRecording() {
    if (!this.recognition) {
      this.showToast('Speech recognition not supported in this browser.');
      return;
    }
    if (this.isRecording) {
      this.recognition.stop();
      this.setRecording(false);
    } else {
      try {
        this.recognition.start();
        this.setRecording(true);
        this.showToast('Listening... Speak now');
      } catch (e) {
        this.setRecording(false);
      }
    }
  }

  speakText(text) {
    if (!('speechSynthesis' in window)) {
      this.showToast('Text-to-speech not supported in this browser.');
      return;
    }

    if (this.isSpeaking) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
      this.updateVoiceButtonState();
      return;
    }

    // Clean markdown before speaking
    const cleanText = text.replace(/[*_#`[\]()]/g, '').slice(0, 500);
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      this.isSpeaking = true;
      this.updateVoiceButtonState();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.updateVoiceButtonState();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.updateVoiceButtonState();
    };

    window.speechSynthesis.speak(utterance);
  }

  updateVoiceButtonState() {
    const voiceBtn = document.getElementById('voice-circle-btn');
    if (voiceBtn) {
      voiceBtn.classList.toggle('speaking', this.isSpeaking);
      voiceBtn.title = this.isSpeaking ? 'Stop speaking' : 'Voice interaction';
    }
  }

  render() {
    const app = document.getElementById('app');
    const activeConv = this.getActiveConversation();

    app.innerHTML = `
      <!-- Sidebar -->
      <aside class="sidebar ${this.sidebarCollapsed ? 'collapsed' : ''}" id="sidebar">
        <div class="sidebar-header">
          <div class="brand-wrapper" id="brand-menu-btn" title="ChatGPT Model Selection">
            <span class="brand-logo-text">ChatGPT</span>
            <span class="brand-chevron">${ICONS.chevronDown}</span>
          </div>
          <div class="sidebar-header-actions">
            <button class="icon-btn" id="search-nav-btn" title="Search chats">
              ${ICONS.search}
            </button>
            <button class="icon-btn" id="sidebar-collapse-btn" title="Collapse sidebar">
              ${ICONS.sidebarToggle}
            </button>
          </div>
        </div>

        <nav class="sidebar-nav">
          <button class="nav-item" id="new-chat-btn">
            ${ICONS.newChat}
            <span>New chat</span>
          </button>
          <button class="nav-item" id="library-btn">
            ${ICONS.library}
            <span>Library</span>
          </button>
          <button class="nav-item" id="projects-btn">
            ${ICONS.projects}
            <span>Projects</span>
          </button>
          <button class="nav-item" id="scheduled-btn">
            ${ICONS.scheduled}
            <span>Scheduled</span>
          </button>
          <button class="nav-item" id="plugins-btn">
            ${ICONS.plugins}
            <span>Plugins</span>
          </button>
          <button class="nav-item" id="codex-btn">
            ${ICONS.codex}
            <span>Codex</span>
          </button>
          <button class="nav-item" id="more-nav-btn">
            ${ICONS.more}
            <span>More</span>
          </button>
        </nav>

        <div class="recents-section">
          <div class="recents-heading">Recents</div>
          <ul class="recents-list" id="recents-list">
            ${this.renderRecentsList()}
          </ul>
        </div>

        <div class="sidebar-footer">
          <button class="user-profile-btn" id="user-profile-btn" title="Settings & Account">
            <div class="avatar-circle">${DEFAULT_USER.initials}</div>
            <div class="user-meta">
              <span class="user-name">${DEFAULT_USER.name}</span>
              <span class="user-plan-badge">${DEFAULT_USER.plan}</span>
            </div>
            <div class="settings-btn-icon">${ICONS.store}</div>
          </button>
        </div>
      </aside>

      <!-- Main Chat Area -->
      <main class="main-chat-container">
        <!-- Top App Bar -->
        <header class="chat-top-bar">
          <div class="top-bar-left">
            ${this.sidebarCollapsed ? `
              <button class="icon-btn" id="sidebar-expand-btn" title="Open sidebar">
                ${ICONS.sidebarToggle}
              </button>
            ` : ''}
            <button class="model-selector-btn" id="model-badge-btn" title="Click to configure AI Model">
              <span>ChatGPT</span>
              <span class="model-badge" id="provider-badge">${this.getProviderBadgeText()}</span>
              ${ICONS.chevronDown}
            </button>
          </div>
          <div class="top-bar-right">
            <button class="share-btn" id="share-chat-btn">
              ${ICONS.share}
              <span>Share</span>
            </button>
            <button class="icon-btn" id="top-more-btn" title="Options">
              ${ICONS.more}
            </button>
          </div>
        </header>

        <!-- Message List -->
        <section class="messages-container" id="messages-container">
          ${this.renderMessages(activeConv.messages)}
        </section>

        <!-- Bottom Input Bar Area -->
        <footer class="chat-bottom-wrapper">
          <!-- File Attachments Preview -->
          <div class="attachment-preview-bar" id="attachment-preview-bar" style="display: ${this.attachedFiles.length ? 'flex' : 'none'};">
            ${this.renderAttachmentPreviews()}
          </div>

          <!-- Rounded Pill Input Container -->
          <div class="input-pill-container">
            <input type="file" id="file-upload-input" style="display: none;" multiple />
            <button class="attach-btn" id="attach-btn" title="Attach file or image">
              ${ICONS.plus}
            </button>

            <textarea 
              id="chat-input" 
              class="chat-textarea" 
              placeholder="Ask anything" 
              rows="1"
            ></textarea>

            <div class="input-actions-group">
              <button class="think-toggle-btn ${this.thinkMode ? 'active' : ''}" id="think-toggle-btn" title="Toggle Deep Thinking reasoning mode">
                ${ICONS.think}
                <span>Think</span>
              </button>

              <button class="mic-btn" id="mic-btn" title="Speech to text">
                ${ICONS.mic}
              </button>

              <button class="voice-circle-btn" id="voice-circle-btn" title="Voice interaction / Read aloud">
                ${ICONS.voiceWave}
              </button>

              <button class="send-arrow-btn" id="send-btn" title="Send message" disabled>
                ${ICONS.arrowUp}
              </button>
            </div>
          </div>

          <div class="input-disclaimer">
            ChatGPT can make mistakes. Check important info.
          </div>
        </footer>
      </main>

      <!-- Modals Container -->
      <div id="modal-container"></div>
    `;

    this.attachEventListeners();
    this.scrollToBottom();
  }

  getProviderBadgeText() {
    const prov = this.aiService.settings.provider;
    if (prov === 'gemini') return 'Gemini 2.0';
    if (prov === 'groq') return 'Groq Llama 3.3';
    if (prov === 'openai') return 'GPT-4o';
    if (prov === 'local') return 'Hackathon Engine';
    return 'Smart Agent';
  }

  renderRecentsList() {
    return this.conversations.map(conv => `
      <li class="recent-chat-item ${conv.id === this.activeConversationId ? 'active' : ''}" data-id="${conv.id}">
        <span class="chat-title-text" title="${conv.title}">${conv.title}</span>
        <div class="chat-item-actions">
          <button class="chat-action-btn edit-chat-btn" data-id="${conv.id}" title="Rename">${ICONS.edit}</button>
          <button class="chat-action-btn delete-chat-btn" data-id="${conv.id}" title="Delete">${ICONS.trash}</button>
        </div>
      </li>
    `).join('');
  }

  renderMessages(messages) {
    if (!messages || messages.length === 0) {
      return `
        <div style="text-align: center; margin: auto; max-width: 480px; color: var(--text-muted); padding: 40px 20px;">
          <div style="margin-bottom: 16px;">${ICONS.chatgpt}</div>
          <h2 style="font-size: 22px; color: #fff; margin-bottom: 8px;">What's on your mind today?</h2>
          <p style="font-size: 14px; line-height: 1.5;">Ask anything about Hackathons, SIH Problem Statements, Database Optimization, System Design, or Full-Stack Architecture.</p>
        </div>
      `;
    }

    return messages.map(msg => {
      if (msg.role === 'user') {
        return `
          <div class="message-wrapper user" id="${msg.id}">
            <div class="user-bubble">${this.escapeHtml(msg.content)}</div>
          </div>
        `;
      } else {
        const parsedMarkdown = marked.parse(msg.content || '');
        const thoughtHtml = msg.thought ? `
          <div class="thought-container">
            <div class="thought-header" onclick="this.parentElement.classList.toggle('collapsed')">
              <span class="pulse-dot"></span>
              <span>Thought for a few seconds</span>
              <span style="margin-left: auto;">${ICONS.chevronDown}</span>
            </div>
            <div class="thought-body">${this.escapeHtml(msg.thought)}</div>
          </div>
        ` : '';

        return `
          <div class="message-wrapper assistant" id="${msg.id}">
            ${thoughtHtml}
            <div class="assistant-content markdown-body">
              ${parsedMarkdown}
            </div>
            <div class="message-actions-bar">
              <button class="action-icon-btn copy-msg-btn" data-text="${encodeURIComponent(msg.content)}" title="Copy response">${ICONS.copy}</button>
              <button class="action-icon-btn thumbs-up-btn" title="Good response">${ICONS.thumbsUp}</button>
              <button class="action-icon-btn thumbs-down-btn" title="Bad response">${ICONS.thumbsDown}</button>
              <button class="action-icon-btn retry-msg-btn" data-id="${msg.id}" title="Regenerate response">${ICONS.retry}</button>
              <button class="action-icon-btn speak-msg-btn" data-text="${encodeURIComponent(msg.content)}" title="Read aloud">${ICONS.speaker}</button>
              <button class="action-icon-btn share-msg-btn" title="Share">${ICONS.share}</button>
              <button class="action-icon-btn" title="More">${ICONS.more}</button>
            </div>
          </div>
        `;
      }
    }).join('');
  }

  renderAttachmentPreviews() {
    return this.attachedFiles.map((file, idx) => `
      <div class="attachment-chip">
        <span>📎 ${file.name}</span>
        <button class="remove-attachment-btn" data-idx="${idx}">×</button>
      </div>
    `).join('');
  }

  escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  attachEventListeners() {
    // Input & Auto-resize
    const textarea = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');

    if (textarea) {
      textarea.addEventListener('input', () => {
        this.autoResizeTextarea(textarea);
        this.updateSendButtonState();
      });

      textarea.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          this.handleSendMessage();
        }
      });
    }

    if (sendBtn) {
      sendBtn.addEventListener('click', () => this.handleSendMessage());
    }

    // Attach File
    const attachBtn = document.getElementById('attach-btn');
    const fileInput = document.getElementById('file-upload-input');
    if (attachBtn && fileInput) {
      attachBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', (e) => {
        const files = Array.from(e.target.files);
        files.forEach(f => {
          this.attachedFiles.push({ name: f.name, size: f.size });
        });
        this.renderAttachments();
      });
    }

    // Think Toggle
    const thinkBtn = document.getElementById('think-toggle-btn');
    if (thinkBtn) {
      thinkBtn.addEventListener('click', () => {
        this.thinkMode = !this.thinkMode;
        thinkBtn.classList.toggle('active', this.thinkMode);
        this.showToast(this.thinkMode ? '💡 Deep Thinking mode turned ON' : 'Thinking mode turned OFF');
      });
    }

    // Speech to text
    const micBtn = document.getElementById('mic-btn');
    if (micBtn) {
      micBtn.addEventListener('click', () => this.toggleRecording());
    }

    // Voice Read Aloud / Interactive
    const voiceCircleBtn = document.getElementById('voice-circle-btn');
    if (voiceCircleBtn) {
      voiceCircleBtn.addEventListener('click', () => {
        const activeConv = this.getActiveConversation();
        const lastAssistantMsg = [...activeConv.messages].reverse().find(m => m.role === 'assistant');
        if (lastAssistantMsg) {
          this.speakText(lastAssistantMsg.content);
        } else {
          this.showToast('No AI answer to speak yet.');
        }
      });
    }

    // Sidebar collapse / expand
    const collapseBtn = document.getElementById('sidebar-collapse-btn');
    if (collapseBtn) {
      collapseBtn.addEventListener('click', () => {
        this.sidebarCollapsed = true;
        this.render();
      });
    }

    const expandBtn = document.getElementById('sidebar-expand-btn');
    if (expandBtn) {
      expandBtn.addEventListener('click', () => {
        this.sidebarCollapsed = false;
        this.render();
      });
    }

    // Brand Menu / Model selector -> opens settings
    const brandMenuBtn = document.getElementById('brand-menu-btn');
    const modelBadgeBtn = document.getElementById('model-badge-btn');
    if (brandMenuBtn) brandMenuBtn.addEventListener('click', () => this.openSettingsModal());
    if (modelBadgeBtn) modelBadgeBtn.addEventListener('click', () => this.openSettingsModal());

    // User profile -> opens settings
    const userProfileBtn = document.getElementById('user-profile-btn');
    if (userProfileBtn) userProfileBtn.addEventListener('click', () => this.openSettingsModal());

    // Search
    const searchNavBtn = document.getElementById('search-nav-btn');
    if (searchNavBtn) searchNavBtn.addEventListener('click', () => this.openSearchModal());

    // Share chat
    const shareBtn = document.getElementById('share-chat-btn');
    if (shareBtn) shareBtn.addEventListener('click', () => this.openShareModal());

    // New Chat
    const newChatBtn = document.getElementById('new-chat-btn');
    if (newChatBtn) {
      newChatBtn.addEventListener('click', () => this.handleNewChat());
    }

    // Recents chat item click
    document.querySelectorAll('.recent-chat-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (e.target.closest('.chat-item-actions')) return;
        const id = item.getAttribute('data-id');
        this.activeConversationId = id;
        this.render();
      });
    });

    // Delete chat
    document.querySelectorAll('.delete-chat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        this.deleteChat(id);
      });
    });

    // Rename chat
    document.querySelectorAll('.edit-chat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        this.renameChat(id);
      });
    });

    // Copy response buttons
    document.querySelectorAll('.copy-msg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = decodeURIComponent(btn.getAttribute('data-text'));
        navigator.clipboard.writeText(text);
        this.showToast('Copied to clipboard!');
      });
    });

    // Speak message buttons
    document.querySelectorAll('.speak-msg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = decodeURIComponent(btn.getAttribute('data-text'));
        this.speakText(text);
      });
    });

    // Thumbs up / down feedback
    document.querySelectorAll('.thumbs-up-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.classList.toggle('active');
        this.showToast('Thanks for the feedback!');
      });
    });

    document.querySelectorAll('.thumbs-down-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.classList.toggle('active');
        this.showToast('Feedback noted for model improvement.');
      });
    });

    // Retry / Regenerate
    document.querySelectorAll('.retry-msg-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const activeConv = this.getActiveConversation();
        const lastUser = [...activeConv.messages].reverse().find(m => m.role === 'user');
        if (lastUser) {
          this.triggerAssistantGeneration(lastUser.content);
        }
      });
    });

    // Remove attachment chip
    document.querySelectorAll('.remove-attachment-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-idx'));
        this.attachedFiles.splice(idx, 1);
        this.renderAttachments();
      });
    });

    // Copy Code Buttons inside code blocks
    this.setupCodeBlockHeaders();
  }

  setupCodeBlockHeaders() {
    document.querySelectorAll('.assistant-content pre code').forEach(codeBlock => {
      const pre = codeBlock.parentElement;
      if (pre.parentElement.classList.contains('code-block-wrapper')) return;

      const langClass = Array.from(codeBlock.classList).find(c => c.startsWith('language-'));
      const lang = langClass ? langClass.replace('language-', '') : 'code';

      const wrapper = document.createElement('div');
      wrapper.className = 'code-block-wrapper';

      const header = document.createElement('div');
      header.className = 'code-header';
      header.innerHTML = `
        <span>${lang}</span>
        <button class="copy-code-btn">
          ${ICONS.copy}
          <span>Copy code</span>
        </button>
      `;

      header.querySelector('.copy-code-btn').addEventListener('click', () => {
        navigator.clipboard.writeText(codeBlock.innerText);
        const span = header.querySelector('.copy-code-btn span');
        span.innerText = 'Copied!';
        setTimeout(() => { span.innerText = 'Copy code'; }, 2000);
      });

      pre.parentNode.insertBefore(wrapper, pre);
      wrapper.appendChild(header);
      wrapper.appendChild(pre);
      pre.className = 'code-content';
    });
  }

  renderAttachments() {
    const bar = document.getElementById('attachment-preview-bar');
    if (bar) {
      bar.innerHTML = this.renderAttachmentPreviews();
      bar.style.display = this.attachedFiles.length ? 'flex' : 'none';
      document.querySelectorAll('.remove-attachment-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const idx = parseInt(btn.getAttribute('data-idx'));
          this.attachedFiles.splice(idx, 1);
          this.renderAttachments();
        });
      });
    }
  }

  autoResizeTextarea(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 180)}px`;
  }

  updateSendButtonState() {
    const textarea = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    if (textarea && sendBtn) {
      sendBtn.disabled = !textarea.value.trim() && this.attachedFiles.length === 0;
    }
  }

  scrollToBottom() {
    const container = document.getElementById('messages-container');
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  }

  handleNewChat() {
    const newId = 'chat-' + Date.now();
    const newConv = {
      id: newId,
      title: 'New chat',
      timestamp: new Date().toISOString(),
      messages: []
    };
    this.conversations.unshift(newConv);
    this.activeConversationId = newId;
    this.saveConversations();
    this.render();
  }

  deleteChat(id) {
    if (this.conversations.length <= 1) {
      this.showToast('Cannot delete the only conversation.');
      return;
    }
    this.conversations = this.conversations.filter(c => c.id !== id);
    if (this.activeConversationId === id) {
      this.activeConversationId = this.conversations[0].id;
    }
    this.saveConversations();
    this.render();
  }

  renameChat(id) {
    const conv = this.conversations.find(c => c.id === id);
    if (!conv) return;
    const newTitle = prompt('Enter new conversation title:', conv.title);
    if (newTitle && newTitle.trim()) {
      conv.title = newTitle.trim();
      this.saveConversations();
      this.render();
    }
  }

  async handleSendMessage() {
    if (this.currentGenerating) return;
    const textarea = document.getElementById('chat-input');
    const text = textarea?.value?.trim() || '';

    if (!text && this.attachedFiles.length === 0) return;

    let fullPrompt = text;
    if (this.attachedFiles.length > 0) {
      const attachmentsList = this.attachedFiles.map(f => f.name).join(', ');
      fullPrompt = `[Attached files: ${attachmentsList}]\n${text}`;
      this.attachedFiles = [];
      this.renderAttachments();
    }

    textarea.value = '';
    this.autoResizeTextarea(textarea);
    this.updateSendButtonState();

    const activeConv = this.getActiveConversation();

    // If new chat, set title to prompt preview
    if (activeConv.messages.length === 0) {
      activeConv.title = text.slice(0, 30) + (text.length > 30 ? '...' : '');
    }

    const userMsg = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: fullPrompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    activeConv.messages.push(userMsg);
    this.saveConversations();
    this.render();

    await this.triggerAssistantGeneration(fullPrompt);
  }

  async triggerAssistantGeneration(prompt) {
    this.currentGenerating = true;
    const activeConv = this.getActiveConversation();
    const assistantMsgId = 'msg-' + Date.now();

    const assistantMsg = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      thought: this.thinkMode ? 'Analyzing query parameters and architectural requirements...' : null,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    activeConv.messages.push(assistantMsg);
    this.render();

    // Stream updates
    const assistantEl = document.getElementById(assistantMsgId);
    const contentEl = assistantEl?.querySelector('.assistant-content');

    try {
      const result = await this.aiService.generateResponse({
        prompt,
        conversationHistory: activeConv.messages.slice(0, -1),
        thinkMode: this.thinkMode,
        onThought: (thoughtText) => {
          assistantMsg.thought = thoughtText;
          const thoughtBody = assistantEl?.querySelector('.thought-body');
          if (thoughtBody) thoughtBody.innerText = thoughtText;
        },
        onChunk: (accumulated) => {
          assistantMsg.content = accumulated;
          if (contentEl) {
            contentEl.innerHTML = marked.parse(accumulated) + '<span class="typing-cursor"></span>';
            this.setupCodeBlockHeaders();
            this.scrollToBottom();
          }
        }
      });

      assistantMsg.content = result.text;
      assistantMsg.provider = result.provider;
      this.saveConversations();
      this.render();
    } catch (err) {
      assistantMsg.content = `⚠️ **Error generating response:** ${err.message}\n\nPlease check your API key in **Settings** or switch to the Local Hackathon Brain.`;
      this.saveConversations();
      this.render();
    } finally {
      this.currentGenerating = false;
    }
  }

  openSettingsModal() {
    const modalContainer = document.getElementById('modal-container');
    const settings = this.aiService.settings;

    modalContainer.innerHTML = `
      <div class="modal-backdrop" id="modal-backdrop">
        <div class="modal-card">
          <div class="modal-header">
            <h2>AI Agent Settings</h2>
            <button class="icon-btn" id="modal-close-btn">${ICONS.close}</button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Active Provider</label>
              <select class="form-select" id="setting-provider">
                <option value="auto" ${settings.provider === 'auto' ? 'selected' : ''}>Auto Detect (Based on Key)</option>
                <option value="gemini" ${settings.provider === 'gemini' ? 'selected' : ''}>Google Gemini (Free & Fast)</option>
                <option value="groq" ${settings.provider === 'groq' ? 'selected' : ''}>Groq (Llama 3.3 70B - Ultra Fast)</option>
                <option value="openai" ${settings.provider === 'openai' ? 'selected' : ''}>OpenAI (GPT-4o mini)</option>
                <option value="local" ${settings.provider === 'local' ? 'selected' : ''}>Local Hackathon Brain (Zero Key Needed)</option>
              </select>
              <span class="form-helper">Select your preferred AI engine or let it auto-detect.</span>
            </div>

            <div class="form-group">
              <label class="form-label">Google Gemini API Key (Recommended - 100% Free)</label>
              <input type="password" class="form-input" id="setting-gemini-key" placeholder="AIzaSy..." value="${settings.geminiKey || settings.apiKey || ''}" />
              <span class="form-helper">Get a free key instantly from <a href="https://aistudio.google.com/app/apikey" target="_blank" style="color: #3b88fd; text-decoration: underline;">Google AI Studio</a>.</span>
            </div>

            <div class="form-group">
              <label class="form-label">Groq API Key (Optional)</label>
              <input type="password" class="form-input" id="setting-groq-key" placeholder="gsk_..." value="${settings.groqKey || ''}" />
              <span class="form-helper">Free ultra-fast keys at <a href="https://console.groq.com/keys" target="_blank" style="color: #3b88fd; text-decoration: underline;">console.groq.com</a>.</span>
            </div>

            <div class="form-group">
              <label class="form-label">OpenAI API Key (Optional)</label>
              <input type="password" class="form-input" id="setting-openai-key" placeholder="sk-..." value="${settings.openaiKey || ''}" />
            </div>

            <div class="form-group">
              <label class="form-label">System Persona / Instructions</label>
              <textarea class="form-textarea" id="setting-system-prompt" rows="3">${settings.systemPrompt}</textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn-secondary" id="modal-cancel-btn">Cancel</button>
            <button class="btn-primary" id="modal-save-btn">Save Settings</button>
          </div>
        </div>
      </div>
    `;

    const close = () => { modalContainer.innerHTML = ''; };
    document.getElementById('modal-close-btn').addEventListener('click', close);
    document.getElementById('modal-cancel-btn').addEventListener('click', close);
    document.getElementById('modal-backdrop').addEventListener('click', (e) => {
      if (e.target.id === 'modal-backdrop') close();
    });

    document.getElementById('modal-save-btn').addEventListener('click', () => {
      const provider = document.getElementById('setting-provider').value;
      const geminiKey = document.getElementById('setting-gemini-key').value.trim();
      const groqKey = document.getElementById('setting-groq-key').value.trim();
      const openaiKey = document.getElementById('setting-openai-key').value.trim();
      const systemPrompt = document.getElementById('setting-system-prompt').value.trim();

      this.aiService.saveSettings({
        provider,
        geminiKey,
        groqKey,
        openaiKey,
        apiKey: geminiKey || groqKey || openaiKey,
        systemPrompt
      });

      this.showToast('Settings saved successfully!');
      close();
      this.render();
    });
  }

  openSearchModal() {
    const modalContainer = document.getElementById('modal-container');
    modalContainer.innerHTML = `
      <div class="modal-backdrop" id="search-modal-backdrop">
        <div class="modal-card" style="max-width: 600px;">
          <div class="modal-header">
            <h2>Search Conversations</h2>
            <button class="icon-btn" id="search-close-btn">${ICONS.close}</button>
          </div>
          <div class="modal-body">
            <input type="text" class="form-input" id="search-query-input" placeholder="Type keywords (e.g. database, Bloomberg, SIH, plant)..." autofocus />
            <div id="search-results-list" style="margin-top: 12px; display: flex; flex-direction: column; gap: 8px; max-height: 350px; overflow-y: auto;">
              ${this.renderSearchResults('')}
            </div>
          </div>
        </div>
      </div>
    `;

    const close = () => { modalContainer.innerHTML = ''; };
    document.getElementById('search-close-btn').addEventListener('click', close);
    document.getElementById('search-modal-backdrop').addEventListener('click', (e) => {
      if (e.target.id === 'search-modal-backdrop') close();
    });

    const queryInput = document.getElementById('search-query-input');
    queryInput.addEventListener('input', (e) => {
      const resultsContainer = document.getElementById('search-results-list');
      resultsContainer.innerHTML = this.renderSearchResults(e.target.value.trim().toLowerCase());
      this.attachSearchResultClicks(close);
    });

    this.attachSearchResultClicks(close);
  }

  renderSearchResults(q) {
    const matches = this.conversations.filter(c => {
      if (!q) return true;
      if (c.title.toLowerCase().includes(q)) return true;
      return c.messages.some(m => m.content.toLowerCase().includes(q));
    });

    if (matches.length === 0) {
      return `<div style="color: var(--text-subtle); padding: 12px; text-align: center;">No matching conversations found.</div>`;
    }

    return matches.map(c => `
      <div class="search-result-item" data-id="${c.id}" style="padding: 10px 14px; background: rgba(255,255,255,0.05); border-radius: 8px; cursor: pointer; transition: background 0.15s;">
        <div style="font-weight: 500; color: #fff; margin-bottom: 4px;">${c.title}</div>
        <div style="font-size: 12px; color: var(--text-subtle);">${c.messages.length} messages</div>
      </div>
    `).join('');
  }

  attachSearchResultClicks(closeFn) {
    document.querySelectorAll('.search-result-item').forEach(item => {
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-id');
        this.activeConversationId = id;
        closeFn();
        this.render();
      });
    });
  }

  openShareModal() {
    const activeConv = this.getActiveConversation();
    const shareText = activeConv.messages.map(m => `### ${m.role === 'user' ? 'User' : 'ChatGPT'}:\n${m.content}\n`).join('\n---\n');

    const modalContainer = document.getElementById('modal-container');
    modalContainer.innerHTML = `
      <div class="modal-backdrop" id="share-modal-backdrop">
        <div class="modal-card">
          <div class="modal-header">
            <h2>Share / Export Conversation</h2>
            <button class="icon-btn" id="share-close-btn">${ICONS.close}</button>
          </div>
          <div class="modal-body">
            <p style="font-size: 13.5px; color: var(--text-muted); margin-bottom: 12px;">Export or copy your conversation with full formatting:</p>
            <div style="display: flex; gap: 10px; margin-bottom: 16px;">
              <button class="btn-primary" id="copy-markdown-btn" style="flex: 1;">Copy Markdown</button>
              <button class="btn-secondary" id="download-json-btn" style="flex: 1;">Download JSON</button>
            </div>
            <textarea class="form-textarea" rows="8" readonly style="font-size: 12px;">${shareText}</textarea>
          </div>
        </div>
      </div>
    `;

    const close = () => { modalContainer.innerHTML = ''; };
    document.getElementById('share-close-btn').addEventListener('click', close);
    document.getElementById('share-modal-backdrop').addEventListener('click', (e) => {
      if (e.target.id === 'share-modal-backdrop') close();
    });

    document.getElementById('copy-markdown-btn').addEventListener('click', () => {
      navigator.clipboard.writeText(shareText);
      this.showToast('Conversation copied as Markdown!');
      close();
    });

    document.getElementById('download-json-btn').addEventListener('click', () => {
      const blob = new Blob([JSON.stringify(activeConv, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeConv.title.replace(/[^a-zA-Z0-9]/g, '_')}.json`;
      a.click();
      URL.revokeObjectURL(url);
      close();
    });
  }

  showToast(message) {
    const existing = document.querySelector('.toast-notice');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'toast-notice';
    toast.innerText = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 2800);
  }
}

// Instantiate application on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.app = new ChatGPTApp();
});
